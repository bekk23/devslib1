package uz.devslib.app

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import uz.devslib.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding

    private var failedUrl: String? = null
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var syncingNav = false

    private val fileChooser =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
            filePathCallback?.onReceiveValue(uris)
            filePathCallback = null
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        setSupportActionBar(b.toolbar)

        setupWebView()
        setupBottomNav()
        setupRefresh()
        setupBackHandling()

        if (savedInstanceState != null) {
            b.webView.restoreState(savedInstanceState)
        } else {
            val start = intent?.data?.takeIf { it.host == HOST }?.toString() ?: (BASE + "/")
            b.webView.loadUrl(start)
        }
    }

    // ------------------------------------------------------------------ WebView

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val wv = b.webView
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = false
            displayZoomControls = false
            textZoom = 100
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = false
            cacheMode = WebSettings.LOAD_DEFAULT
            userAgentString = "$userAgentString DevsLibApp/1.0"
        }

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(wv, true)
        }

        wv.setDownloadListener { url, _, _, _, _ -> openExternal(Uri.parse(url)) }

        wv.webViewClient = object : WebViewClient() {

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                if (!request.isForMainFrame) return false
                return handleNavigation(request.url)
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                b.progress.visibility = View.VISIBLE
                if (url != null && url.startsWith("http")) syncNavWith(url)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                b.progress.visibility = View.INVISIBLE
                b.swipe.isRefreshing = false
                CookieManager.getInstance().flush()
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: WebResourceError
            ) {
                if (request.isForMainFrame) {
                    failedUrl = request.url.toString()
                    view.loadUrl(OFFLINE_PAGE)
                }
            }

            override fun onRenderProcessGone(
                view: WebView,
                detail: android.webkit.RenderProcessGoneDetail
            ): Boolean {
                recreate()
                return true
            }
        }

        wv.webChromeClient = object : WebChromeClient() {

            override fun onProgressChanged(view: WebView, newProgress: Int) {
                b.progress.setProgressCompat(newProgress, true)
                if (newProgress >= 100) b.progress.visibility = View.INVISIBLE
            }

            override fun onShowFileChooser(
                webView: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                return try {
                    fileChooser.launch(params.createIntent())
                    true
                } catch (e: ActivityNotFoundException) {
                    filePathCallback = null
                    false
                }
            }

            // Video to'liq ekran (YouTube darslar uchun)
            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (customView != null) {
                    callback.onCustomViewHidden()
                    return
                }
                customView = view
                customViewCallback = callback
                b.fullscreenContainer.addView(view)
                b.fullscreenContainer.visibility = View.VISIBLE
                b.mainContent.visibility = View.GONE
                setImmersive(true)
            }

            override fun onHideCustomView() {
                val v = customView ?: return
                b.fullscreenContainer.removeView(v)
                b.fullscreenContainer.visibility = View.GONE
                b.mainContent.visibility = View.VISIBLE
                customView = null
                customViewCallback?.onCustomViewHidden()
                customViewCallback = null
                setImmersive(false)
            }
        }
    }

    /** true qaytarsa — havolani ilova o'zi ochmaydi (tashqi ilovaga beriladi yoki to'xtatiladi). */
    private fun handleNavigation(uri: Uri): Boolean {
        val scheme = uri.scheme.orEmpty()
        val host = uri.host.orEmpty()

        if (scheme == "retry") {
            b.webView.loadUrl(failedUrl ?: (BASE + "/"))
            return true
        }
        if (scheme == "file") return false
        if ((scheme == "http" || scheme == "https") && host == HOST) return false

        // YouTube embed havolasini YouTube ilovasida oddiy video sifatida ochish
        if (host.endsWith("youtube.com") && uri.path.orEmpty().startsWith("/embed/")) {
            val id = uri.lastPathSegment
            if (!id.isNullOrEmpty()) {
                openExternal(Uri.parse("https://www.youtube.com/watch?v=$id"))
                return true
            }
        }

        openExternal(uri)
        return true
    }

    private fun openExternal(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.no_app_for_link, Toast.LENGTH_SHORT).show()
        }
    }

    // ------------------------------------------------------------ Bottom navigation

    private fun setupBottomNav() {
        b.bottomNav.setOnItemSelectedListener { item ->
            if (!syncingNav) SECTIONS[item.itemId]?.let { b.webView.loadUrl(BASE + it) }
            true
        }
        b.bottomNav.setOnItemReselectedListener { item ->
            if (!syncingNav) SECTIONS[item.itemId]?.let { b.webView.loadUrl(BASE + it) }
        }
    }

    private fun syncNavWith(url: String) {
        val uri = Uri.parse(url)
        if (uri.host != HOST) return
        val path = uri.path.orEmpty()
        val id = when {
            path.isEmpty() || path == "/" -> R.id.nav_home
            path.startsWith("/darsliklar") -> R.id.nav_tutorials
            path.startsWith("/texnologiyalar") -> R.id.nav_tech
            path.startsWith("/kurslar") -> R.id.nav_courses
            path.startsWith("/wiki") -> R.id.nav_wiki
            else -> return
        }
        if (b.bottomNav.selectedItemId != id) {
            syncingNav = true
            b.bottomNav.selectedItemId = id
            syncingNav = false
        }
    }

    // ------------------------------------------------------------------ Refresh

    private fun setupRefresh() {
        b.swipe.setColorSchemeResources(R.color.accent)
        // Sahifa tepasida bo'lgandagina "tortib yangilash" ishlasin
        b.swipe.setOnChildScrollUpCallback { _, _ -> b.webView.scrollY > 0 }
        b.swipe.setOnRefreshListener {
            val current = b.webView.url
            if (current == null || current.startsWith("file:")) {
                b.webView.loadUrl(failedUrl ?: (BASE + "/"))
            } else {
                b.webView.reload()
            }
        }
    }

    // ---------------------------------------------------------------- Back button

    private fun setupBackHandling() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    customView != null -> b.webView.webChromeClient?.onHideCustomView()
                    b.webView.canGoBack() -> b.webView.goBack()
                    else -> {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })
    }

    private fun setImmersive(on: Boolean) {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        if (on) {
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    // ------------------------------------------------------------------ Toolbar menu

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_refresh -> b.swipe.apply {
                isRefreshing = true
                b.webView.reload()
            }
            R.id.action_developers -> b.webView.loadUrl("$BASE/dasturchilar/")
            R.id.action_sign_in -> b.webView.loadUrl("$BASE/sign-in")
            R.id.action_sign_up -> b.webView.loadUrl("$BASE/sign-up")
            R.id.action_about -> b.webView.loadUrl("$BASE/about-us/")
            R.id.action_terms -> b.webView.loadUrl("$BASE/terms-of-use/")
            R.id.action_ads -> b.webView.loadUrl("$BASE/reklama/")
            R.id.action_telegram -> openExternal(Uri.parse(TELEGRAM))
            R.id.action_share -> shareCurrentPage()
            R.id.action_open_browser -> openExternal(
                Uri.parse(b.webView.url?.takeIf { it.startsWith("http") } ?: (BASE + "/"))
            )
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    private fun shareCurrentPage() {
        val url = b.webView.url?.takeIf { it.startsWith("http") } ?: (BASE + "/")
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, url)
        }
        startActivity(Intent.createChooser(send, getString(R.string.share)))
    }

    // ------------------------------------------------------------------ Lifecycle

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        b.webView.saveState(outState)
    }

    override fun onResume() {
        super.onResume()
        b.webView.onResume()
    }

    override fun onPause() {
        b.webView.onPause()
        CookieManager.getInstance().flush()
        super.onPause()
    }

    override fun onDestroy() {
        filePathCallback?.onReceiveValue(null)
        filePathCallback = null
        b.webView.destroy()
        super.onDestroy()
    }

    companion object {
        private const val HOST = "devslib.pythonanywhere.com"
        private const val BASE = "https://$HOST"
        private const val TELEGRAM = "https://t.me/dybredly"
        private const val OFFLINE_PAGE = "file:///android_asset/offline.html"

        private val SECTIONS = mapOf(
            R.id.nav_home to "/",
            R.id.nav_tutorials to "/darsliklar/",
            R.id.nav_tech to "/texnologiyalar/",
            R.id.nav_courses to "/kurslar/",
            R.id.nav_wiki to "/wiki/"
        )
    }
}
