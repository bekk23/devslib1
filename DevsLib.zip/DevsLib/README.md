# DevsLib — Android ilova

[devslib.pythonanywhere.com](https://devslib.pythonanywhere.com/) (Dasturchilar Kutubxonasi) saytining Android ilovasi.
Kotlin + WebView, minSdk 26 (Android 8.0+).

## Imkoniyatlari

- Pastki navigatsiya: Bosh sahifa, Darsliklar, Texnologiyalar, Kurslar, Wiki
- Yuqoridagi menyu: Dasturchilar, Kirish, Ro'yxatdan o'tish, Telegram, Ulashish, Brauzerda ochish, Biz haqimizda va h.k.
- Sahifani pastga tortib yangilash (pull-to-refresh) va yuklanish chizig'i
- Internet yo'q bo'lganda "Qayta urinish" ekrani
- Tizimga kirish (login) sessiyasi saqlanadi (cookie)
- Sayt ichidagi havolalar ilovada, tashqi havolalar (Telegram, Wikipedia, YouTube) tashqi ilovada ochiladi
- YouTube darslarini to'liq ekranda ko'rish
- Orqaga tugmasi sahifalar tarixi bo'ylab ishlaydi
- Yorug' va qorong'i rejim uchun mos ranglar
- Fayl yuklash (rasm tanlash) qo'llab-quvvatlanadi

## Ochish va ishga tushirish

1. [Android Studio](https://developer.android.com/studio) (Koala yoki yangiroq) o'rnating.
2. `File > Open` orqali shu papkani tanlang va Gradle sinxronlanishini kuting.
3. Telefonni ulang (USB debugging yoqilgan) yoki emulyator yarating va **Run** tugmasini bosing.

## APK yig'ish

Terminalda:

```bash
./gradlew assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`

Google Play uchun imzolangan fayl kerak bo'lsa: `Build > Generate Signed Bundle / APK`.

## Sozlash

- Sayt manzili, Telegram havolasi: `app/src/main/java/uz/devslib/app/MainActivity.kt` (`companion object`)
- Matnlar: `app/src/main/res/values/strings.xml`
- Ranglar: `app/src/main/res/values/colors.xml` (qorong'i rejim: `values-night`)
- Ikonka: `app/src/main/res/drawable/ic_launcher_foreground.xml`
- Paket nomi (`applicationId`): `app/build.gradle.kts` — Google Play uchun o'zingiznikiga almashtiring
